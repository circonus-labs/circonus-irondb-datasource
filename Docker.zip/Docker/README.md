# Build process
* export GRAFANA_API_KEY=<grafana_api_key_here>
* Install Docker
* run build.sh